README
-
SEO Sitemap Mod for SMF by http://kress.it.

Simplemachines forum modification

SEO Sitemap &copy; 2012, Markus Kress - Kress.IT.

#### License 
http://creativecommons.org/licenses/by-sa/3.0/deed.de CC BY-SA

-
#### Support 
1. http://kress.it and
2. http://custom.simplemachines.org/mods/index.php?mod=3393
