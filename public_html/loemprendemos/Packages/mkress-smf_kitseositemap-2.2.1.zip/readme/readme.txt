SEO Sitemap by [url=http://kress.it]kress.it[/url]
/*******************************************************************************
* SEO Sitemap � 2012, Markus Kress - Kress.IT							       *
********************************************************************************
* readme.txt																   *
********************************************************************************
* License http://creativecommons.org/licenses/by-sa/3.0/deed.de CC BY-SA	   *
* Support for this software  http://kress.it and							   *
* http://custom.simplemachines.org/mods/index.php?mod=3393					   *
*******************************************************************************/