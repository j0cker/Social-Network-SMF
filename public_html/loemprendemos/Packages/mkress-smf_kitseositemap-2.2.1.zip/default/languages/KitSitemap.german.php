<?php
/*******************************************************************************
* SEO Sitemap � 2012, Markus Kress - Kress.IT							       *
********************************************************************************
* KitSitemap.german.php														   *
********************************************************************************
* License http://creativecommons.org/licenses/by-sa/3.0/deed.de CC BY-SA 	   *
* Support for this software  http://kress.it and							   *
* http://custom.simplemachines.org/mods/index.php?mod=3393					   *
*******************************************************************************/

global $scripturl;
$txt['kitsitemap_mainlink_desc'] = 'Vollversion anzeigen:';
$txt['kitsitemap_archive'] = '[Archiv]';
$txt['kitsitemap_mod'] = 'SEO Sitemap &amp; XML-Sitemap';
$txt['kitsitemap_footer'] = 'Links im Footer<br /><span class="smalltext">&raquo; <a href="'.$scripturl.'?action=kitsitemap">Sitemap anzeigen</a>';
$txt['kitsitemap_footer_hide'] = 'ausblenden';
?>