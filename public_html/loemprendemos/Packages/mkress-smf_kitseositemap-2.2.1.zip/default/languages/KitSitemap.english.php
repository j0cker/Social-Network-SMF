<?php
/*******************************************************************************
* SEO Sitemap � 2012, Markus Kress - Kress.IT							       *
********************************************************************************
* KitSitemap.english.php													   *
********************************************************************************
* License http://creativecommons.org/licenses/by-sa/3.0/deed.de CC BY-SA 	   *
* Support for this software  http://kress.it and							   *
* http://custom.simplemachines.org/mods/index.php?mod=3393					   *
*******************************************************************************/

global $scripturl;
$txt['kitsitemap_mainlink_desc'] = 'View full version:';
$txt['kitsitemap_archive'] = '[Archive]';
$txt['kitsitemap_mod'] = 'SEO sitemap &amp; XML sitemap';
$txt['kitsitemap_footer'] = 'Footer links<br /><span class="smalltext">&raquo; <a href="'.$scripturl.'?action=kitsitemap">show sitemap</a>';
$txt['kitsitemap_footer_hide'] = 'hide';
?>