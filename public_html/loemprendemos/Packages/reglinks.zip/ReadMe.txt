*******************************
Registered Links Version 3.0
By: vbgamer45
http://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.0.x and SMF 1.1.x

Allows you stop guests from viewing links. Informs them to register or login.

Other mods:
SMF Gallery
SMF Store
SMF Classifieds
Downloads System Pro
Newsletter Pro
EzPortal
Social Login Pro
Ad Seller Pro

http://www.smfhacks.com
